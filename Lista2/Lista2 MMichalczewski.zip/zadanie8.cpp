//8. Uzasadnij, że w każdym drzewie BST zawsze ponad połowa wskaźników (pól left i
//right) jest równa NULL.

/*
Wynika to z faktu, że liście, czyli ostatnie wartości nie mają więcej potomków. 
*/